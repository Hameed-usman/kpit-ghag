"""
Ghag – POST /api/v1/ask router.

Accepts voice or text queries.
Answers strictly from verified KB entries.
Validates source_id in code — forces human handoff if unconfident or source is invalid.
Returns JSON with text, simulated SMS, and base64 TTS audio.

FR-1, FR-2, FR-3, FR-4, FR-5, FR-6, FR-7
"""
from __future__ import annotations

import logging
import time
from typing import Optional

from fastapi import APIRouter, File, Form, HTTPException, Request, Response, UploadFile

from app.config import settings
from app.schemas import AskResponse, Lang, Outcome
from app.services import kb, llm, logstore, stt, tts

log = logging.getLogger(__name__)

router = APIRouter(prefix="/api/v1", tags=["ask"])

HANDOFF_MESSAGES: dict[str, str] = {
    "ur": "معذرت، میں اس سوال کا جواب سرکاری دستاویزات سے نہیں دے سکتا۔ براہ کرم اپنے ضلعی ڈی سی آفس یا cfc.kp.gov.pk سے رابطہ کریں۔",
    "ps": "بخښنه غواړم، زه نشم کولی د رسمي اسنادو له مخې د دې پوښتنې ځواب ورکړم. مهرباني وکړئ د خپلې ولسوالۍ DC دفتر یا cfc.kp.gov.pk سره اړیکه ونیسئ۔",
    "en": "I'm sorry, I cannot find verified official information to answer this question. Please contact your local Deputy Commissioner (DC) Office or visit cfc.kp.gov.pk.",
}

HANDOFF_SMS: dict[str, str] = {
    "ur": "معلومات دستیاب نہیں۔ DC آفس یا cfc.kp.gov.pk سے رابطہ کریں۔",
    "ps": "معلومات نشته. DC دفتر یا cfc.kp.gov.pk سره اړیکه ونیسئ.",
    "en": "Info unavailable in verified KB. Contact DC Office or visit cfc.kp.gov.pk.",
}

_NOISE_TOKENS = {
    "موسیقی", "[موسیقی]", "music", "[music]", "music.", "applause", "[applause]",
    "خاموشی", "[خاموشی]", "sound", "...", "subtitles by", "amara.org", "thanks for watching",
}

_GREETING_TRIGGERS = {
    "سلام", "السلام علیکم", "اسلام علیکم", "ہیلو", "hello", "hi", "hey",
    "good morning", "good afternoon", "good evening", "سلامونه", "پخیر",
    "aao", "aoa", "assalam o alaikum", "assalam alaikum", "salam",
}

_COURTESY_TRIGGERS = {
    "شکریہ", "شکریہ۔", "بہت شکریہ", "مہربانی", "تھینک یو", "thank you", "thanks",
    "thank you very much", "مننه", "ډیره مننه", "thanks a lot",
}

_UNCLEAR_AUDIO_MESSAGES: dict[str, str] = {
    "ur": "معذرت، آپ کی آواز صاف نہیں سنی جا سکی۔ براہ کرم مائیک کے قریب ہو کر اپنا سوال دوبارہ بولیے۔",
    "ps": "بخښنه غواړم، ستاسو غږ صفا ونه اورېدل شو. مهرباني وکړئ خپله پوښتنه بیا تکرار کړئ.",
    "en": "Pardon me, I could not hear your question clearly. Please speak closer to the microphone and ask again.",
}

_ALLOWED_AUDIO_EXTENSIONS = {"wav", "webm", "mp3", "ogg", "m4a", "flac"}

_GREETING_TEXTS: dict[str, str] = {
    "ur": "السلام علیکم! خیبر پختونخوا سٹیزن ہیلپ لائن میں خوش آمدید۔ ڈومیسائل کے بارے میں آپ کو کیا معلومات چاہیے؟",
    "ps": "سلام علیکم! د خیبر پختونخوا ولسي خدمت مرکز ته ښه راغلاست. د ډومیسائل سند په اړه تاسو ته څه معلومات پکار دي؟",
    "en": "Hello and welcome to Khyber Pakhtunkhwa Citizen Facilitation. How may I assist you with your Domicile Certificate today?",
}

_WAIT_TEXTS: dict[str, str] = {
    "ur": "جی، میں آپ کے لیے سرکاری ریکارڈ دیکھ رہا ہوں، ذرا انتظار کیجیے۔",
    "ps": "ستاسو لپاره رسمي ریکارډ کتل کیږي، لږ انتظار وکړئ.",
    "en": "Checking verified government records for you, one moment please.",
}

_GOODBYE_TEXTS: dict[str, str] = {
    "ur": "شکریہ! حکومت خیبر پختونخوا کے سٹیزن پورٹل سے رابطہ کرنے کا شکریہ۔ آپ کسی بھی وقت دوبارہ رابطہ کر سکتے ہیں۔ اللہ حافظ!",
    "ps": "مننه! د خیبر پختونخوا ولسي خدمت مرکز سره د تماس لپاره مننه. تاسو هر وخت بیا اړیکه نیولی شئ. د خدای پامان!",
    "en": "Thank you for contacting Khyber Pakhtunkhwa Citizen Facilitation. You may connect again anytime. Have a great day!",
}

_CALL_AUDIO_CACHE: dict[str, bytes] = {}


@router.get("/call/greeting")
async def call_greeting(lang: str = "ur"):
    """Return pre-synthesized call agent greeting MP3 audio."""
    target_lang = lang if lang in ("ur", "ps", "en") else "ur"
    cache_key = f"greeting_{target_lang}"
    if cache_key not in _CALL_AUDIO_CACHE:
        text = _GREETING_TEXTS.get(target_lang, _GREETING_TEXTS["ur"])
        audio = await tts.synthesize(text, lang=target_lang)
        if audio:
            _CALL_AUDIO_CACHE[cache_key] = audio
    audio_bytes = _CALL_AUDIO_CACHE.get(cache_key)
    if not audio_bytes:
        raise HTTPException(status_code=503, detail="Greeting audio unavailable")
    return Response(content=audio_bytes, media_type="audio/mpeg")


@router.get("/call/wait")
async def call_wait(lang: str = "ur"):
    """Return pre-synthesized call agent wait/checking MP3 audio."""
    target_lang = lang if lang in ("ur", "ps", "en") else "ur"
    cache_key = f"wait_{target_lang}"
    if cache_key not in _CALL_AUDIO_CACHE:
        text = _WAIT_TEXTS.get(target_lang, _WAIT_TEXTS["ur"])
        audio = await tts.synthesize(text, lang=target_lang)
        if audio:
            _CALL_AUDIO_CACHE[cache_key] = audio
    audio_bytes = _CALL_AUDIO_CACHE.get(cache_key)
    if not audio_bytes:
        raise HTTPException(status_code=503, detail="Wait audio unavailable")
    return Response(content=audio_bytes, media_type="audio/mpeg")


@router.get("/call/goodbye")
async def call_goodbye(lang: str = "ur"):
    """Return pre-synthesized call agent goodbye MP3 audio."""
    target_lang = lang if lang in ("ur", "ps", "en") else "ur"
    cache_key = f"goodbye_{target_lang}"
    if cache_key not in _CALL_AUDIO_CACHE:
        text = _GOODBYE_TEXTS.get(target_lang, _GOODBYE_TEXTS["ur"])
        audio = await tts.synthesize(text, lang=target_lang)
        if audio:
            _CALL_AUDIO_CACHE[cache_key] = audio
    audio_bytes = _CALL_AUDIO_CACHE.get(cache_key)
    if not audio_bytes:
        raise HTTPException(status_code=503, detail="Goodbye audio unavailable")
    return Response(content=audio_bytes, media_type="audio/mpeg")


@router.post("/ask", response_model=AskResponse)
async def ask_endpoint(
    request: Request,
    audio: Optional[UploadFile] = File(None),
    text: Optional[str] = Form(None),
    lang: Optional[str] = Form(None),
    lang_hint: Optional[str] = Form(None),
) -> AskResponse:
    """
    Core voice/text question-answering endpoint.
    Accepts multipart form-data (audio + optional text/lang) or application/json.
    """
    t0 = time.perf_counter()

    # If client submitted application/json, parse JSON body
    content_type = request.headers.get("content-type", "").lower()
    if "application/json" in content_type:
        try:
            json_body = await request.json()
            if isinstance(json_body, dict):
                text = text or json_body.get("text") or json_body.get("question")
                lang = lang or json_body.get("lang")
                lang_hint = lang_hint or json_body.get("lang_hint")
        except Exception as e:
            log.warning("Failed to parse JSON body in /ask: %s", e)

    # 1. Validation
    if audio is None and (not text or not text.strip()):
        raise HTTPException(
            status_code=400,
            detail="Neither audio nor text was provided. Please speak or type your question.",
        )

    # Determine effective language hint
    effective_hint: Optional[str] = None
    if lang_hint and lang_hint.lower().strip() != "auto":
        effective_hint = lang_hint.lower().strip()
    elif lang and lang.lower().strip() in ("ur", "ps", "en"):
        effective_hint = lang.lower().strip()

    transcript: str = ""
    detected_lang: str = effective_hint or "en"

    # 2. STT Path
    if audio is not None:
        audio_bytes = await audio.read()
        if len(audio_bytes) > settings.max_audio_bytes:
            raise HTTPException(
                status_code=413,
                detail=f"Audio file exceeds maximum allowed size ({settings.max_audio_bytes} bytes).",
            )

        filename = audio.filename or "audio.wav"
        ext = filename.rsplit(".", 1)[-1].lower() if "." in filename else ""
        if ext and ext not in _ALLOWED_AUDIO_EXTENSIONS:
            raise HTTPException(
                status_code=422,
                detail=f"Unsupported audio format: '.{ext}'. Supported: {', '.join(_ALLOWED_AUDIO_EXTENSIONS)}",
            )

        try:
            stt_result = await stt.transcribe(audio_bytes, filename=filename, lang_hint=effective_hint)
            transcript = str(stt_result)
            if hasattr(stt_result, "lang") and stt_result.lang in ("ur", "ps", "en"):
                detected_lang = stt_result.lang
        except stt.STTError as exc:
            log.error("STT failed: %s", exc)
            if not settings.demo_mode:
                raise HTTPException(
                    status_code=503,
                    detail="Voice transcription service temporarily unavailable.",
                ) from exc
            transcript = "ڈومیسائل سرٹیفکیٹ کے لیے کیا کرنا ہوگا؟"
            detected_lang = effective_hint or "ur"

        # Check if Whisper output is a known acoustic noise hallucination or empty
        clean_tr = transcript.strip().lower()
        # Only treat as noise if: empty, pure whitespace, in known noise set, OR
        # extremely short AND the content is non-word characters only
        is_noise = (
            len(clean_tr) == 0
            or clean_tr in _NOISE_TOKENS
            or (len(clean_tr) < 2)
        )
        if is_noise:
            unclear_msg = _UNCLEAR_AUDIO_MESSAGES.get(detected_lang, _UNCLEAR_AUDIO_MESSAGES["ur"])
            audio_bytes = await tts.synthesize(unclear_msg, lang=detected_lang)
            audio_b64 = tts.to_base64_data_uri(audio_bytes) if audio_bytes else None
            latency_ms = max(1, int((time.perf_counter() - t0) * 1000))
            return AskResponse(
                transcript=transcript or "Unclear audio",
                lang=Lang(detected_lang),
                answer=unclear_msg,
                outcome=Outcome.handoff,
                source_id=None,
                source_url=None,
                last_verified=None,
                confident=False,
                handoff_reason="Audio signal unclear / ambient noise detected",
                latency_ms=latency_ms,
                sms_text="آواز صاف نہ ہونے کی وجہ سے سوال نہیں سنا گیا۔ دوبارہ رابطہ کریں۔",
                audio_b64=audio_b64,
                tts_available=audio_b64 is not None,
            )
    else:
        # Text Path
        transcript = (text or "").strip()
        if detected_lang not in ("ur", "ps", "en"):
            detected_lang = "en"

    # 3. Grounded LLM Generation
    active_kb = kb.get_kb()
    normalized_q = transcript.strip().lower().rstrip(".!؟? ")

    # Polite Greeting check
    if normalized_q in _GREETING_TRIGGERS:
        greet_texts = {
            "ur": "وعلیکم السلام! خیبر پختونخوا سٹیزن ہیلپ لائن میں خوش آمدید۔ ڈومیسائل کے 500 روپے سرکاری فیس، درکار کاغذات، یا 7 روزہ پروسیسنگ کے بارے میں آپ کیا جاننا چاہتے ہیں؟",
            "ps": "سلام علیکم! د خیبر پختونخوا ولسي خدمت مرکز ته ښه راغلاست. د ډومیسائل 500 روپۍ فیس، پکار اسنادو یا طریقی په اړه څه پوښتنه لرئ؟",
            "en": "Hello and welcome to Khyber Pakhtunkhwa Citizen Facilitation. How may I assist you with the KP Domicile Certificate, Rs. 500 official fee, required documents, or the 7-day timeline?",
        }
        greet_sms = {
            "ur": "KP ڈومیسائل معلومات: فیس 500 روپے، 7 دن کی مدت، DC آفس یا cfc.kp.gov.pk پر دستیاب۔",
            "ps": "KP ډومیسائل: 500 روپۍ فیس، 7 ورځې موده، DC دفتر یا cfc.kp.gov.pk.",
            "en": "KP Domicile: Rs. 500 fee, 7-day timeline. Visit cfc.kp.gov.pk or DC Office.",
        }
        ans_text = greet_texts.get(detected_lang, greet_texts["ur"])
        sms_text = greet_sms.get(detected_lang, greet_sms["ur"])
        audio_bytes = await tts.synthesize(ans_text, lang=detected_lang)
        audio_b64 = tts.to_base64_data_uri(audio_bytes) if audio_bytes else None
        latency_ms = max(1, int((time.perf_counter() - t0) * 1000))
        logstore.log_query(
            lang=detected_lang,
            source_id="dom-channels",
            handled="answered",
            question_text=transcript,
            is_demo=settings.demo_mode,
        )
        return AskResponse(
            transcript=transcript,
            lang=Lang(detected_lang),
            answer=ans_text,
            outcome=Outcome.answered,
            source_id="dom-channels",
            source_url=active_kb.get_source_url("dom-channels"),
            last_verified=active_kb.get_last_verified("dom-channels"),
            confident=True,
            handoff_reason=None,
            latency_ms=latency_ms,
            sms_text=sms_text,
            audio_b64=audio_b64,
            tts_available=audio_b64 is not None,
        )

    # Polite Courtesy / Thank-you check
    if normalized_q in _COURTESY_TRIGGERS:
        courtesy_texts = {
            "ur": "آپ کا خیر مقدم ہے! اگر آپ کو ڈومیسائل سرٹیفکیٹ، درکار کاغذات، یا درخواست کے طریقہ کار کے بارے میں مزید معلومات چاہیے ہوں، تو میں حاضر ہوں۔",
            "ps": "ستاسو ډیره مننه! که تاسو د ډومیسائل سند، اسنادو یا فیس په اړه نور معلومات غواړئ، نو زه ستاسو په خدمت کې یم.",
            "en": "You are welcome! Please let me know if you need any additional information regarding the KP Domicile Certificate, required documents, or application procedure.",
        }
        courtesy_sms = {
            "ur": "حکومت خیبر پختونخوا سٹیزن پورٹل سے رابطہ کرنے کا شکریہ۔",
            "ps": "د خیبر پختونخوا ولسي خدمت مرکز سره د رابطې لپاره مننه.",
            "en": "Thank you for contacting Khyber Pakhtunkhwa Citizen Facilitation.",
        }
        ans_text = courtesy_texts.get(detected_lang, courtesy_texts["ur"])
        sms_text = courtesy_sms.get(detected_lang, courtesy_sms["ur"])
        audio_bytes = await tts.synthesize(ans_text, lang=detected_lang)
        audio_b64 = tts.to_base64_data_uri(audio_bytes) if audio_bytes else None
        latency_ms = max(1, int((time.perf_counter() - t0) * 1000))
        logstore.log_query(
            lang=detected_lang,
            source_id="dom-channels",
            handled="answered",
            question_text=transcript,
            is_demo=settings.demo_mode,
        )
        return AskResponse(
            transcript=transcript,
            lang=Lang(detected_lang),
            answer=ans_text,
            outcome=Outcome.answered,
            source_id="dom-channels",
            source_url=active_kb.get_source_url("dom-channels"),
            last_verified=active_kb.get_last_verified("dom-channels"),
            confident=True,
            handoff_reason=None,
            latency_ms=latency_ms,
            sms_text=sms_text,
            audio_b64=audio_b64,
            tts_available=audio_b64 is not None,
        )

    try:
        answer_result = await llm.grounded_answer(
            question=transcript,
            kb=active_kb,
            lang_hint=detected_lang,
        )
    except llm.LLMError as exc:
        log.error("LLM generation failed: %s", exc)
        if not settings.demo_mode:
            raise HTTPException(
                status_code=503,
                detail="Language reasoning service temporarily unavailable.",
            ) from exc
        answer_result = llm._demo_answer(detected_lang)

    # 4. Strict Validation in Code: Never trust the LLM on source_id!
    valid_source = active_kb.source_id_valid(answer_result.source_id)
    if not valid_source and answer_result.confident and not (answer_result.source_id and answer_result.source_id.strip()):
        # Only recover when source_id was completely omitted (empty string) on short follow-up voice query
        recovered_id = active_kb.find_matching_section_id(transcript, answer_result.answer)
        if recovered_id and active_kb.source_id_valid(recovered_id):
            log.info("P-2 Source ID Recovery: Auto-mapped to '%s'", recovered_id)
            answer_result.source_id = recovered_id
            valid_source = True

    is_confident = answer_result.confident and valid_source

    response_lang = answer_result.lang if answer_result.lang in ("ur", "ps", "en") else detected_lang

    # 5. Route to Handoff vs Answered
    if not is_confident:
        if answer_result.confident and not valid_source:
            log.warning(
                "P-2 Violation Intercepted: LLM claimed confidence but provided invalid source_id '%s'. Forcing handoff.",
                answer_result.source_id,
            )
        handoff_answer = HANDOFF_MESSAGES.get(response_lang, HANDOFF_MESSAGES["en"])
        handoff_sms = HANDOFF_SMS.get(response_lang, HANDOFF_SMS["en"])

        # Try TTS for handoff message
        audio_bytes = await tts.synthesize(handoff_answer, lang=response_lang)
        audio_b64 = tts.to_base64_data_uri(audio_bytes) if audio_bytes else None

        # Log query
        logstore.log_query(
            lang=response_lang,
            source_id=None,
            handled="handoff",
            question_text=transcript,
            is_demo=settings.demo_mode,
        )

        latency_ms = max(1, int((time.perf_counter() - t0) * 1000))
        return AskResponse(
            transcript=transcript,
            lang=Lang(response_lang),
            answer=handoff_answer,
            outcome=Outcome.handoff,
            source_id=None,
            source_url=None,
            last_verified=None,
            confident=False,
            handoff_reason="Out of verified government knowledge base scope",
            latency_ms=latency_ms,
            sms_text=handoff_sms,
            audio_b64=audio_b64,
            tts_available=audio_b64 is not None or audio_bytes is not None,
        )

    # 6. Answered Path
    source_url = active_kb.get_source_url(answer_result.source_id)
    last_verified = active_kb.get_last_verified(answer_result.source_id)
    latency_ms = max(1, int((time.perf_counter() - t0) * 1000))

    # Synthesize speech
    mp3_bytes = await tts.synthesize(answer_result.answer, lang=response_lang)
    audio_b64 = tts.to_base64_data_uri(mp3_bytes) if mp3_bytes else None
    tts_available = (mp3_bytes is not None)

    # Log query
    logstore.log_query(
        lang=response_lang,
        source_id=answer_result.source_id,
        handled="answered",
        question_text=transcript,
        is_demo=settings.demo_mode,
    )

    return AskResponse(
        transcript=transcript,
        lang=Lang(response_lang),
        answer=answer_result.answer,
        outcome=Outcome.answered,
        source_id=answer_result.source_id,
        source_url=source_url,
        last_verified=last_verified,
        confident=True,
        handoff_reason=None,
        latency_ms=latency_ms,
        sms_text=answer_result.sms,
        audio_b64=audio_b64,
        tts_available=tts_available,
    )
